/*
Secondary bootloader C code that finally loads and jumps to the kernel entry point.
At this point the kernel should be in protected 32-bit mode.
Could add more code that reads from the filesystem, etc. But currently it loads the
kernel after sector 4 (2048) then jumps to the kernel entry routine.
*/

#ifdef i386
#include <drive.h>
#include <i386.h>
#endif

#include <memlayout.h>
#include <elf.h>

/* Kernel starts at sector 4 or 4*512 = 2048 bytes. */
#define KERNELSTART 2048

void x86stosb(void *, unsigned int, unsigned int);

static int readseg(void *, unsigned int, unsigned int);
static int memcmp(const unsigned char *, const unsigned char *, unsigned int);
static void memset(unsigned char *, int, unsigned int);

/* Second stage bootloader starts here. */
void
_start(void)
{
	struct elfhdr *elf;
	struct proghdr *ph, *eph;
	void (*entry) (int, int, int , void *);

	elf = (struct elfhdr *) 0x10000; /* Scratch space. */

	/* Read 1st page off disk to where kernel starts */
	if (readseg(elf, KERNELSTART, 4096))
		return;

	/* Check if it is an elf file */
	if (memcmp(elf->e_ident, ELFMAGIC, sizeof(ELFMAGIC) - 1))
		return;

	/* Load each program segment (ignores ph flags). */
	ph = (struct proghdr *) ((unsigned char *) elf + elf->e_phoff);
	eph = ph + elf->e_phnum;
	for (; ph < eph; ++ph) {
		unsigned char *tmp = (unsigned char *) ph->ph_paddr;
		if (ph->ph_filesz && readseg(tmp, ph->ph_offset + KERNELSTART, ph->ph_filesz))
			return;

		// Zero any extra memory.
		if (ph->ph_memsz > ph->ph_filesz)
			//memset(tmp + ph->ph_filesz, 0, ph->ph_memsz - ph->ph_filesz);
			x86stosb(tmp + ph->ph_filesz, 0, ph->ph_memsz - ph->ph_filesz);
	}

	/*
	Call entry point to kernel
	Arguments:
		- RB_AUTOBOOT
		- No boot device
		- No memory maps (for now).
	*/
	entry = (void (*)(int, int, int, void *)) (elf->e_entry);
	entry(0, 0, 0, (void *) 0);
}

static int
memcmp(const unsigned char *s1, const unsigned char *s2, unsigned int n)
{
	register const unsigned char *e = s1 + n;
	for (; s1 < e; ++s1, ++s2)
		if (*s1 != *s2)
			return (const char) *s1 - (const char) *s2;
	return 0;
}

static void
memset(unsigned char *s, int val, unsigned int n)
{
	register const unsigned char *e = s + n;
	for (; s < e; ++s)
		*s = val;
}

/* Load count (bytes) from offset sector (bytes) to destination */
static int
readseg(void *dst, unsigned int obytes, unsigned int cbytes)
{
	unsigned char *srt = dst, *end = (unsigned char *) dst + cbytes;

	/* Round down to sector boundary */
	srt -= obytes % SECTSIZE;

	/* Map bytes to sectors rounding up. */
	if (cbytes % SECTSIZE)
		cbytes = cbytes/SECTSIZE + 1;
	else
		cbytes /= SECTSIZE;

	if (srt < end) {
		/* Map bytes to sectors rounding down. */
		obytes /= SECTSIZE;

		/* Can read at most 256 sectors at once. */
		for (; cbytes >= 256; cbytes -= 256) {
			/* Count of 0 means 256 sectors. */
			if (pio28read(srt, 0x1f0, obytes, 0))
				return 1;

			srt += 256*SECTSIZE;
			obytes += 256;
		}

		/* Read any remaining sectors. */
		if (cbytes)
			return pio28read(srt, 0x1f0, obytes, cbytes);
	}
	return 0;
}
