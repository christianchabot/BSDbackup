
# usage: cksz.sh file maxtextsize totalsize [sign]

# Check the size of the text is small enough.
BOOTSZ=$(wc -c $1 | cut -f 1 -d ' ')
if [ $BOOTSZ -gt $2 ]; then
	printf '%s too large: %d bytes (max %d)\n' $1 $((BOOTSZ)) $(($2))
	exit 1
fi

printf '%s is %d bytes (max %d)\n' $1 $((BOOTSZ)) $(($2))

# Add zeros to the end of the file
if [ $(($3-$BOOTSZ)) -ne 0 ]; then
	dd ibs=1 obs=1 if=/dev/zero of=$1 seek=$BOOTSZ count=$(($3-$BOOTSZ)) 2> /dev/null
	if [ $? -ne 0 ]; then
		exit 1
	fi
fi

# Sign the boot block if the argument was given.
if [ -n "$4" ]; then
	printf $4 >> $1
	if [ $? -ne 0 ]; then
		exit 1
	fi
fi
