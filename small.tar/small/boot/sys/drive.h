#ifndef _DRIVE_H_
#define _DRIVE_H_

#define SECTSIZE 512

int
pio28read(void *, unsigned int, unsigned int, unsigned int);

#endif
