#ifndef _BIOS_H_
#define _BIOS_H_

/* smap structure used by bios memory map. */
struct smap {
	unsigned int basel, baseh;
	unsigned int lenl, lenh;
	unsigned int type, acpi;
};

#endif
