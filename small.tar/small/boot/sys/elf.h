#ifndef _ELF_H_
#define _ELF_H_

struct elfhdr {
	unsigned char e_ident[16];
	unsigned short e_type;
	unsigned short e_machine;
	unsigned int e_version;
	unsigned int e_entry;
	unsigned int e_phoff;
	unsigned int e_shoff;
	unsigned int e_flags;
	unsigned short e_ehsize;
	unsigned short e_phentsize;
	unsigned short e_phnum;
	unsigned short e_shentsize;
	unsigned short e_shnum;
	unsigned short e_shstrndx;
};

struct proghdr {
	unsigned int ph_type;
	unsigned int ph_offset;
	unsigned long ph_vaddr;
	unsigned long ph_paddr;
	unsigned long ph_filesz;
	unsigned long ph_memsz;
	unsigned int ph_flags;
	unsigned long ph_align;
};

/* Thank you, Wikipedia. */
struct secthdr {
	/*
	Offset to a string in the .shstrtab section that represents the name of this section.
	*/
	unsigned int sh_name;
	unsigned int sh_type; /* Type of header. */
	unsigned long sh_flags; /* Attributes of the section. */
	unsigned long sh_addr; /* Virtual address of the section in memory. */
	unsigned long sh_offset; /* Offset of the section in the file image. */
	unsigned long sh_size; /*Size in bytes of the section in the file image. May be 0. */

	/*
	Section index of an associated section.
	This field is used depending on the type of section.
	*/
	unsigned int sh_link;

	/*
	Contains extra information about the section.
	This field is used for several purposes, depending on the type of section.
	*/
	unsigned int sh_info;
	unsigned long sh_addralign; /* Alignment of the section. Field must be power of 2. */

	/*
	Contains the size, in bytes, of each entry,
	for sections that contain fixed-size entries.
	Othersise, this field contains zero.
	*/
	unsigned long sh_entsize;
};

/* Values for Proghdr type */
#define ELF_PROG_LOAD           1

/* Flag bits for Proghdr flags */
#define ELF_PROG_FLAG_EXEC      1
#define ELF_PROG_FLAG_WRITE     2
#define ELF_PROG_FLAG_READ      4

#define ELFMAGIC "\x7F" "ELF"

#endif
