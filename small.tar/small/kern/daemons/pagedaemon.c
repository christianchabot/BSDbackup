/*
Selects what pages to swap to disk.
Traditionally pid 2.
uses vm_pageout()
*/
void
_start(void)
{

}
