/*
traditionally pid 1.
init daemon starts /sbin/init
*/
void
_start(void)
{
	
}
