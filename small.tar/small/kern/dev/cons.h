#ifndef _DEVICE_CONS_H_
#define _DEVICE_CONS_H_

struct consdev {
	int (*d_open)(void);
	int (*d_close)(void);
	int (*d_read)(void);
	int (*d_write)(void);
	int (*d_ioctl)(void);
};

void consinit(void);

#endif
