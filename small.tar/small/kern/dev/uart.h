#ifndef _DEVICE_UART_H_
#define _DEVICE_UART_H_

/* OS dev. */

#define IEROFSET 1 /* Interrupt enable register. offset. */
#define IIROFSET 2 /* Interrupt Identification register offset. */
#define FCROFSET 2 /* FIFO control register offset. */
#define LCROFSET 3 /* Line control register offset. */
#define MCROFSET 4 /* Modem control register offset. */
#define LSROFSET 5 /* Line status register offset. */
#define MSROFSET 6 /* Modem status register offset. */
#define SROFSET  7 /* Scratch register offset. */

/* Interrupt Enable Register. */
#define IER_RECVDATA  0x01 /* Enable recieve data available interrupt. */
#define IER_TRANHREI  0x02 /* Enable transmitter holding register empty interrupt. */
#define IER_RECVLSI   0x04 /* Enable reciver line status interrupt. */
#define IER_MODSI     0x08 /* Enable modem status interrupt. */
#define IER_SLEEPMODE 0x10 /* Enable sleep mode (16750). */
#define IER_LOWPOWMOD 0x20 /* Enable low power mode (16750). */
#define IER_RESERVED1 0x40 /* Reserved. */
#define IER_RESERVED2 0x80 /* Reserved. */

/* Interrupt Identification Register. */
#define IIR_INTRPEND  0x01 /* Interrupt pending. */
#define IIR_MSTINTR   0x00 /* Modem status interrupt. */
#define IIR_THREINTR  0x02 /* Transmitter holding register empty interrupt. */
#define IIR_RDAINTR   0x04 /* Received data available interrupt. */
#define IIR_RLSINTR   0x06 /* Receiver line status interrupt. */
#define IIR_RESERVED1 0x08 /* Reserved. */
#define IIR_RESERVED2 0x0a /* Reserved. */
#define IIR_TOPNDINTR 0x0c /* Time-out Interrupt Pending (16550 & later). */
#define IIR_RESERVED3 0x0e /* Reserved. */
#define IIR_RESERVED4 0x10 /* Reserved. */
#define IIR_64FIFOEN  0x20 /* 64 byte FIFO enabled (16750 only). */
#define IIR_NOFIFO    0x00 /* No FIFO on chip. */
#define IIR_RESERVED5 0x40 /* Reserved. */
#define IIR_FIFONFUNC 0x80 /* FIFO enabled, but not functioning. */
#define IIR_FIFOENABL 0xc0 /* FIFO enabled. */

/* FIFO Control Register. */
#define FCR_ENABLE    0x01 /* Enable FIFO. */
#define FCR_CLRRESV   0x02 /* Clear receive FIFO. */
#define FCR_CLRTRAN   0x04 /* Clear transmit FIFO. */
#define FCR_DMAMODE   0x08 /* DMA mode select (Unused). */
#define FCR_RESERVED  0x10 /* Reserved. */
#define FCR_64BYTE    0x20 /* Enable 64 byte FIFO (16750). */
#define FCR_INTLEVEL0 0x00 /* Interrupt trigger level 1 byte */
#define FCR_INTLEVEL1 0x40 /* Interrupt trigger level 4 byte or 16 byte. */
#define FCR_INTLEVEL2 0x80 /* Interrupt trigger level 8 byte or 32 byte. */
#define FCR_INTLEVEL3 0xc0 /* Interrupt trigger level 14 byte or 56 byte. */

/* Line control register. */
#define LCR_DATA5    0x00 /* 5 bit data. */
#define LCR_DATA6    0x01 /* 6 bit data. */
#define LCR_DATA7    0x02 /* 7 bit data. */
#define LCR_DATA8    0x03 /* 8 bit data. */
#define LCR_STOP1    0x00 /* 1 Stop bit. */
#define LCR_STOP2    0x04 /* 1.5 / 2 stop bits. */
#define LCR_PARNONE  0x00 /* Parity none. */
#define LCR_PARODD   0x08 /* Parity odd. */
#define LCR_PAREVEN  0x18 /* Parity even. */
#define LCR_PARMARK  0x28 /* Parity mark. */
#define LCR_PARSPACE 0x38 /* Parity space. */
#define LCR_SETBREAK 0x40 /* Set break enable. */
#define LCR_DLAB     0x80 /* Divisor Latch Access Bit. */

/* Modem Control Register. */
#define MCR_DATARDY  0x01 /* Data terminal ready. */
#define MCR_RQSTSND  0x02 /* Request to send. */
#define MCR_AUXOUT1  0x04 /* Auxiliary output 1. */
#define MCR_AUXOUT2  0x08 /* Auxiliary output 2. */
#define MCR_LOOPBCK  0x10 /* Loopback mode. */
#define MCR_AUTOFCE  0x20 /* Autoflow control enabled (16750). */
#define MCR_RESERVE1 0x40 /* Reserved. */
#define MCR_RESERVE2 0x80 /* Reserved. */

/* Line Status Register. */
#define LSR_DATARDY   0x01 /* Data ready. */
#define LSR_OVERERR   0x02 /* Overrun error. */
#define LSR_PARITYERR 0x04 /* Parity error. */
#define LSR_FRAMEERR  0x08 /* Framing error. */
#define LSR_BREAKINT  0x10 /* Break interrupt. */
#define LSR_EMPTYTHR  0x20 /* Empty transmitter holding register. */
#define LSR_EMPTYDHR  0x40 /* Empty data holding registers. */
#define LSR_RECVERR   0x80 /* Error in received FIFO */

/* Modem Status Register. */
#define MSR_DCLRTOSND 0x01 /* Delta clear to send. */
#define MSR_DDATASRDY 0x02 /* Delta data set ready. */
#define MSR_EDGRNGIND 0x04 /* Trailing edge ring indicator. */
#define MSR_DDATACDCT 0x08 /* Delta data carrier detect. */
#define MSR_CLRTOSND  0x10 /* Clear to send. */
#define MSR_DATASRDY  0x20 /* Data set ready. */
#define MSR_RNGIND    0x40 /* Ring indicator. */
#define MSR_CDCT      0x80 /* Carrier detect. */

#define DLLOW(baud) ((baud) & 0xff)
#define DLHIGH(baud) ((baud) >> 8)

#define B0      0    /* Hang up. */
#define B50     2304
#define B75     1536
#define B110    1047
#define B135    857  /* 134.5 */
#define B150    768
#define B220    524  /* ? */
#define B300    384
#define B600    192
#define B1200   96
#define B1800   64
#define B2000   58
#define B2400   48
#define B3600   32
#define B4800   24
#define B7200   16
#define B9600   12
#define B19200  6
#define B28800  4
#define B38400  3
#define B57600  2
#define B115200 1

#endif
