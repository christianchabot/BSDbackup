
/* Console device. */
extern int inituart386(void);
extern void uartwrite386(char *, unsigned int);

void
consinit(void)
{
	/*
	if (!inituart386()) {
		// Init IRQs here.

		uartwrite386("vmunix: hello!\n", sizeof("vmunix: hello!\n") - 1);
	}
	*/
}
