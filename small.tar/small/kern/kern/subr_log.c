#include <sys/msgbuf.h>

/* TODO: Figure out if I want to keep it statically allocated. */
static struct msgbuf msgbuf = {MSG_MAGIC};
struct msgbuf *msgbufp = &msgbuf;

/* Initialize any locks needed in msgbuf. */
void
initmsgbuf(void)
{

}


