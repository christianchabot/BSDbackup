#include <sys/proc.h>
#include <sys/lock.h>

extern struct proc proc0;
extern struct pcb pcb0;

/* Simple array of proc structure pointers. */
struct proc *proctab[NPROC] = {&proc0};
struct proc **curproc = proctab, **newproc = proctab;

/* Initialze all static values for proc0. */
struct user paddr0 = {
	&pcb0,
	(void *) 0,
	(void *) 0,
	(void *) 0,
};
struct proc proc0 = {
	(void *) 0,
	(void *) 0,
	(void *) 0,
	&paddr0,
	proctab /* Slot 0 in proc table */
};

static unsigned long proccnt = 1, mproccnt;
static int lock = SPINUNLOCK, mlock = SPINUNLOCK;
/*
Use dynamic memory allocation to allocate proc.
Should allocate the necessary things on creation of a process such as:
	- cpuinfo
	- vmspace
*/
static struct proc *
allocproc(void)
{
	struct proc *r = (void *) 0;
	spinlock(&mlock);
	++mproccnt;
	spinunlock(&mlock);
	return r;
}

/* Free proc from dynamic memory. */
static void
freeproc(struct proc *p)
{
	if (p) {
		struct proc zero = {0};
		spinlock(&mlock);
		*p = zero;
		--mproccnt;
		spinunlock(&mlock);
	}
}

/*
Uses a temporary value which means the slot is taken but the
proc structure was not allocated yet, this allows other processes
to read the proctab without waiting for memory allocation of the
underlying proc structure.

allocproctabslot is the slowest part..
*/
static struct proc **
allocproctabslot(void)
{
	struct proc **r = (void *) 0;
	spinlock(&lock);

	/*
	Search for the next available slot in proctab. Slowest of all proctab functions.
	Could make this nicer by having multiple spinlocks on different sections of
	the proctab. Then when searching for a new proc the whole table doesn't have to 
	be locked (maybe..).
	*/
	if (proccnt < NPROC) {
		/* Find next NULL slot. */
		while (curproc) {
			if (curproc >= proctab + sizeof(proctab)/sizeof(*proctab)) {
				curproc = proctab + 1; /* proc0 is fixed in memory. */
				continue;
			}

			++curproc;
		}

		/* Found a slot */
		r = curproc;
		*r = (struct proc *) 1; /* Mark slot taken */
		++proccnt;
	}

	spinunlock(&lock);
	return r;
}

static void
deleteproctabslot(struct proc **ptslot)
{
	spinlock(&lock);
	*ptslot = (void *) 0;
	--proccnt;
	spinunlock(&lock);
}

struct proc *
createproc(void)
{
	/* Done in this order for fairness to other processes */
	/* 1. Allocate proctab slot. */
	struct proc **r = allocproctabslot();
	if (r) {
		/* 2. Allocate struct proc in dynamic memory */
		struct proc *p = allocproc();
		if (p) {
			/* 3. Aquire spinlock on proctab again and remove tmp value */
			spinlock(&lock);
			p->p_proc = r;
			*r = p;
			spinunlock(&lock);
			return *r;
		}

		deleteproctabslot(r);
	}

	return (void *) 0;
}

void
deleteproc(struct proc *p)
{
	/* Should never call this with proc0 */
	deleteproctabslot(p->p_proc);
	freeproc(p);
}

struct proc *
findproc(int pid)
{
	struct proc *r = (void *) 0;
	if (pid < NPROC && pid >= 0) {
		spinlock(&lock);
		r = proctab[pid];
		spinunlock(&lock);
		/* If marked temporary then proc mem not avail yet */
		if (r == (void *) 1)
			r = (void *) 0;
	}
	return r;
}

/*
Notes:

Benefits to having a statically allocated proc table:
	- NULL values are uninitialzed values.
	- No need to zero the proc table upon entry into
	the kernel.
	- This also gives us compression because p_filesz < p_memsz
	so the bootloader 0's the remaining memory before kernel entry.
	- The process limit is fixed on most kernels anyways.
	- Using pointers allows 1024 entries per page (on 80386).
*/
