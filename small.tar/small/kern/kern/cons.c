
/* Console stuff. */

void
cninit(void)
{

}
