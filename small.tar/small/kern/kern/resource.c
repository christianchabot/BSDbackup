#include <sys/resource.h>

/*
Default userspace rlimit values.
If NULL in proc kernel uses to determine action.
*/
const struct rlimit urlimit = {0};
