#include <sys/param.h>

char *kmembase, *kmemlimit;

void *
malloc(unsigned long size, int flags)
{
	unsigned char *r = 0;
	return r;
}

void
free(void *ptr)
{
	
}

/*
memc - count of memory arrays.
memv - array of memory regions.
*/
void
kmeminit(int memc, int *memv)
{
	unsigned long cnt = 0;
	for (; memc; --memc)
		cnt += *(memv + 1);

	/* Allocate the virtual memory in the kernel. */
}
