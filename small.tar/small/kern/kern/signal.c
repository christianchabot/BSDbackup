#include <sys/signal.h>

/*
Default user signal values.
If NULL in proc kernel uses to determine action.
*/
const struct signal usignal = {0};
