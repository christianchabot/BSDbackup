#include <stdarg.h> /* Provided by the compiler implementation. */

#define TOUPPER (1 << 8)
#define SIGNED  (2 << 8)

#define BASE(flags) ((flags) & 0xff)
#define FLAG(flags) ((flags) >> 8)

/* Hacker's delight. */
static unsigned long
div10(unsigned long n)
{
	unsigned long r, q;
	q = (n >> 1) + (n >> 2);
	q = q + (q >> 4);
	q = q + (q >> 8);
	q = q + (q >> 16);
	q = q >> 3;
	r = n - ((q << 2) + q << 1);
	return q + (r > 9);
}

static unsigned long
mod10(unsigned long n)
{
	unsigned long r = n & 1;
	n >>= 1;

	n = (n >> 16) + (n & 0xffff);
	n = (n >> 8) + (n & 0xff);
	n = (n >> 4) + (n & 0xf);
	if (n > 14)
		n -= 15;

	if (n > 4)
		n -= 5;
	if (n > 4)
		n -= 5;
	return r + (n << 1);
}

static void
printlong(void (*putc) (int), long val, int flags)
{
	static const char dig[] = {
		'0', '1', '2', '3', '4', '5', '6', '7', '8', '9', 'a', 'b', 'c', 'd', 'e', 'f',
		'0', '1', '2', '3', '4', '5', '6', '7', '8', '9', 'A', 'B', 'C', 'D', 'E', 'F'
	};
	int shift, toupper;
	/*
	Largest 64 bit number is 20 digits.
	Largest 32 bit number is 10 digits.
	*/
	char buf[20], *ptr = buf;

	switch (BASE(flags)) {
	case 16:
		/* Do not print leading 0's. */
		for (shift = (sizeof(int) << 3) - 4; shift > 0; shift -= 4)
			if (val >> shift & 0xf)
				break;

		toupper = flags & TOUPPER ? 16 : 0;
		for (; shift > 0; shift -= 4)
			putc(dig[toupper + (val >> shift & 0xf)]);
		putc(dig[toupper + (val & 0xf)]);
		break;
	case 10:
		if (flags & SIGNED && val < 0) {
			putc('-');
			val = -val;
		}

		do {
			/* Should I just use the / and % operators? */
			*ptr++ = dig[mod10(val)]; /* Is this unnecessary? */
			val = div10(val);         /* This too? */
		} while (val);

		do {
			putc(*--ptr);
		} while (ptr > buf);
		break;
	case 8:
		break;
	default:
		break;
	}
}

static void
vprintf(void (*putc) (int), const char *fmt, va_list ap)
{
	const char *tmp, *end;
	long dec;
	for (end = fmt; *end; ++end) {
		int flags;
		if (*end != '%') {
			putc(*end);
			continue;
		}

		flags = 0;
		switch (*++end) {
		case 'X':
			flags |= TOUPPER;
		case 'x':
		case 'p':
			flags += 6;
		case 'd':
			flags |= SIGNED;
		case 'u':
			flags += 2;
		case 'o':
			flags += 8;
			dec = va_arg(ap, int);
			printlong(putc, dec, flags);
			break;
		case 's':
			tmp = va_arg(ap, const char *);
			if (!tmp)
				tmp = "(null)";

			do {
				putc(*tmp);
			} while (*++tmp);
			break;
		default:
			putc('%');
		case '%':
			if (*end)
				putc(*end);
			break;
		}
	}
}

void
printf(void (*putc) (int), const char *fmt, ...)
{
	va_list ap;
	va_start(ap, fmt);
	vprintf(putc, fmt, ap);
	va_end(ap);
}
