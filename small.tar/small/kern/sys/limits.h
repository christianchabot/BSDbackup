#ifndef _SYS_LIMITS_H_
#define _SYS_LIMITS_H_

/* Minimum values for now. */
#define ARG_MAX 4096
#define CHILD_MAX 25
#define LINK_MAX 8
#define MAX_CANON 255
#define MAX_INPUT 255
#define NAME_MAX 14
#define NGROUPS_MAX 8
#define OPEN_MAX 20
#define PATH_MAX 256
#define PIPE_BUF 512
#define SYMLINK_MAX 255
#define SYMLOOP_MAX 8
#define BC_BASE_MAX 99
#define BC_DIM_MAX 2048
#define BC_SCALE_MAX 99
#define BC_STRING_MAX 1000
#define COLL_WEIGHTS_MAX 2
#define EXPR_NEST_MAX 32
#define LINE_MAX 2048
#define RE_DUP_MAX 255
#define SEM_VALUE_MAX
#define IOV_MAX 16
#define NZERO 20
#define TTY_NAME_MAX 9
#define LOGIN_NAME_MAX 9
#define HOST_NAME_MAX 255

#endif
