#ifndef _SYS_MALLOC_H_
#define _SYS_MALLOC_H_

/* Here so we do not mess with std C */
void *malloc(unsigned long, int);
void free(void *);


#endif
