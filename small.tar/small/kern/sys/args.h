
/* variadic stuff. */

/* Should make this in assembly and instead use bytes. */

#define va_start(ap, argN) (void) ((ap) = (char *) (&(argN) + 1))
#define va_arg(ap, type) (((type *) ((ap) = ((ap) + sizeof(type))))[-1])
#define va_end(ap) (void) ((ap) = 0)

typedef char *va_list;

/*
amd64 ABI:

va_start initializes the struct as follows:

reg_save_area: the element points to the start of the register save area.

overflow_arg_area: The pointer is used to fetch arguments passed on the stack.
	It is initialized with the address of the first argument passed on the
	stack, if any, and then always updated to point to the start of the
	next argument on the stack.

gp_offset: The element holds the offset in bytes from reg_save_area to the
	place where the next available general purpose argument register is
	saved. In case all argument registers have been exhausted, it is set to
	the value 48 (6 * 8)

fp_offset: The element holds the offset in bytes from reg_save_area to the place
	where the next available floating point argument register is saved. In
	case all argument registers have been exhausted, it is set to the value
	304 (6 * 8 + 16 * 16)

typedef struct {
	void *reg_save_area;
	void *overflow_arg_area;
	unsigned int gp_offset;
	unsigned int fp_offset;
} va_list[1];

register save area: (only registers that might be used to pass arguments need to be saved)
	register  offset
	rdi       0
	rsi       8
	rdx       16
	rcx       24
	r8        32
	r9        40
	xmm0      48
	xmm1      64
	...
	xmm15     288
*/
