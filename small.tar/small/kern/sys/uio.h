#ifndef _UIO_H_
#define _UIO_H_

/* uio and iov structures here. */

#endif
