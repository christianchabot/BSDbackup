#ifndef _SYS_SYSTM_H_
#define _SYS_SYSTM_H_

void printf(char *, ...);
void panic(char *, ...);

#endif
