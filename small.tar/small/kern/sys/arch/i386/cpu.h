#ifndef _MACHINE_CPU_H_
#define _MACHINE_CPU_H_

/*
MULTIPROCESSOR > 0 to define a fixed amount of cpus otherwise auto-detected.
*/

#if defined(MULTIPROCESSOR) && MULTIPROCESSOR > 0
#define NCPU MULTIPROCESSOR
#else
#define NCPU 1
#endif

/* Each cpu has one of these. */
struct cpu_info {
	int tmp;
};

#endif
