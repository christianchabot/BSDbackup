#ifndef _MACHINE_PARAM_H_
#define _MACHINE_PARAM_H_

#include <i386/page.h>

#define MACHINE "i386"

/*
Mapping to virtual address 0xf0000000 leaves the kernel
to fit in about 252M (256M - 4M of page tables) of RAM.
This is more then enough memory.
*/

/* locore.S is sensitive to any change, make sure you know what you are doing here. */
#define KERNBASE 0xf0000000 /* Start of kernel virtual address. */
#define KERNTEXTOFF 0x100000 /* Start of kernel text address. */
#define KERNVTEXTOFF (KERNBASE + KERNTEXTOFF)
#define KERNENDOFF(end) PGROUND((end) - KERNBASE) /* Find end of kernel */

#endif
