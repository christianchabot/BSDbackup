#ifndef _MACHINE_PAGE_H_
#define _MACHINE_PAGE_H_

/*
Use parenthesis because assemblers and C compilers have different operator precedence.
*/

/* BSD book. */
#define NBPG 4096
#define PGSHIFT 12
#define PGMASK 0xfffff000
#define PGOFSET (NBPG - 1)

#define PGTRUNC(addr) ((addr) & PGMASK) /* Round down. */
#define PGROUND(addr) (((addr) + PGOFSET) & PGMASK) /* Round up. */

#endif
