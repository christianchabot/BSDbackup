#ifndef _MACHINE_PTE_H_
#define _MACHINE_PTE_H_

#define NPDENTR 1024 /* # PDEs per PD. */
#define NPTENTR 1024 /* # PTEs per PT. */

#define PDSHIFT 22 /* Offset of PDE linear address. */
#define PTSHIFT 12 /* Offset of PTE linear address. */

#define PDMASK 0xffc00000
#define PTMASK 0x003ff000

#define PDOFSET(off) ((off) >> (PDSHIFT - 2))
#define PTOFSET(off) ((off) >> (PTSHIFT - 2))

#define NBPDE (1 << PDSHIFT) /* Number of bytes mapped in a pde. */
#define NBPTE (1 << PTSHIFT) /* Number of bytes mapped in a pte. */

/* Intel documentation. */
#define PDE_P  0x001 /* Page table present. */
#define PDE_W  0x002 /* PT has writeable entries. */
#define PDE_U  0x004 /* User mode PTE. */
#define PDE_WT 0x008 /* Page-level write-through. */
#define PDE_CD 0x010 /* Page-level cache disable. */
#define PDE_A  0x020 /* PDE accessed. */
#define PDE_PS 0x080 /* Maps a 4M page. */

#define PTE_P    0x0001 /* Page present. */
#define PTE_W    0x0002 /* Page writeable. */
#define PTE_U    0x0004 /* Page user mode. */
#define PTE_WT   0x0008 /* Page-level write-through. */
#define PTE_CD   0x0010 /* Page-level cache disable. */
#define PTE_A    0x0020 /* Page accessed. */
#define PTE_D    0x0040 /* Page dirty. */
#define PTEK_PAT 0x0080 /* PAT bit for 4K page. */
#define PTEM_PS  0x0080 /* Page size bit for 4M page. */
#define PTE_G    0x0100 /* Page global. */
#define PTEM_PAT 0x1000 /* PAT bit for 4M page. */

#endif
