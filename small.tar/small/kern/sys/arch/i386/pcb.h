#ifndef _MACHINE_PCB_H_
#define _MACHINE_PCB_H_

#include <i386/tss.h>

/* Should be aligned on 128 byte boundary. */
struct pcb {
	struct tss pcb_tss; /* because tss needs to be aligned on 128 byte boundary. */
	/* Remaining 128 - 104 = 24 bytes for extra stuff. */
};

#endif
