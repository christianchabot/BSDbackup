#ifndef _MACHINE_SPECIALREG_H_
#define _MACHINE_SPECIALREG_H_

#define CR0_PE 0x00000001 /* Protection mode enable. */
#define CR0_MP 0x00000002 /* Math coprocessor present. */
#define CR0_EM 0x00000004 /* Emulate NPX */
#define CR0_TS 0x00000008 /* Process has done Task Swicth, do NPX save */
#define CR0_ET 0x00000010 /* 32 bit (if set) vs 16 bit (387 vs 287) */
#define CR0_PG 0x80000000 /* Paging enable. */

#endif
