#ifndef _MACH_FLAG_H_
#define _MACH_FLAG_H_

#define EFLAG_MMX 0x00800000 /* Cpu supports MMX technology. */

#endif
