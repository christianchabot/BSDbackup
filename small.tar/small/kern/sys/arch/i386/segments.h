#ifndef _MACHINE_SEGMENTS_H_
#define _MACHINE_SEGMENTS_H_

/* Type field encoding for system segments and gates. */
#define SDT_SYSNULL   0  /* Undefined */
#define SDT_SYS286TSS 1  /* Available 286 TSS */
#define SDT_SYSLDT    2  /* LDT */
#define SDT_SYS286BSY 3  /* Busy 286 TSS */
#define SDT_SYS286CGT 4  /* 286 Call Gate */
#define SDT_SYSTASKGT 5  /* Task Gate */
#define SDT_SYS286IGT 6  /* 286 Interrupt Gate */
#define SDT_SYS286TGT 7  /* 286 Trap Gate */
#define SDT_SYSNULL2  8  /* Undefined */
#define SDT_SYS386TSS 9  /* Available 386 TSS */
#define SDT_SYSNULL3  10 /* Undefined */
#define SDT_SYS386BSY 11 /* Busy 386 TSS */
#define SDT_SYS386CGT 12 /* 386 Call Gate */
#define SDT_SYSNULL4  13 /* Undefined */
#define SDT_SYS386IGT 14 /* 386 Interrupt Gate */
#define SDT_SYS386TGT 15 /* 386 Trap Gate */

/* Type field encoding for memory segments. */
#define SDT_MEMRO   0  /* Read-only */
#define SDT_MEMROA  1  /* Read-only; accessed */
#define SDT_MEMRW   2  /* Read/write */
#define SDT_MEMRWA  3  /* Read/write; accessed */
#define SDT_MEMROD  4  /* Read-only; expand-down limit */
#define SDT_MEMRODA 5  /* Read-only; expand-down limit, accessed */
#define SDT_MEMRWD  6  /* Read/write; expand-down limit */
#define SDT_MEMRWDA 7  /* Read/write; expand-down limit, accessed */
#define SDT_MEME    8  /* Execute-only */
#define SDT_MEMEA   9  /* Execute-only, accessed */
#define SDT_MEMER   10 /* Execute/read */
#define SDT_MEMERA  11 /* Execute/read, accessed */
#define SDT_MEMEC   12 /* Execute-only, conforming */
#define SDT_MEMEAC  13 /* Execute-only, conforming, accessed */
#define SDT_MEMERC  14 /* Execute/read, conforming */
#define SDT_MEMERAC 15 /* Execute/read, conforming, accessed */

/* Segment Attributes. */
#define SD_DT   0x10 /* Descriptor DType */
#define SD_DPL0 0x00 /* Descriptor Privilege Level 0 */
#define SD_DPL1 0x20 /* Descriptor Privilege Level 1 */
#define SD_DPL2 0x40 /* Descriptor Privilege Level 2 */
#define SD_DPL3 0x60 /* Descriptor Privilege Level 3 */
#define SD_P    0x80 /* Descriptor Present */

#define SD_AVL 0x10 /* Descriptor Available-to-Software */
#define SD_D   0x40 /* Descriptor D bit */
#define SD_G   0x80 /* Descriptor Granularity */

/* Selectors */
#define SEL_KPL 0x0
#define SEL_UPL 0x3
#define SEL_LDT	0x4 /* Selector for local descriptor table. */

#define GNULL_SEL  0  /* Null descriptor. */
#define GCODE_SEL  1  /* Kernel code descriptor. */
#define GDATA_SEL  2  /* Kernel data descriptor. */
#define GUCODE_SEL 3  /* User code descriptor. */
#define GUDATA_SEL 4  /* User data descriptor. */
#define GTSS_SEL   5  /* TSS descriptor. */

#define LSEL(s, r) (((s) << 3) | (r) | SEL_LDT)
#define GSEL(s, r) (((s) << 3) | (r))

#endif
