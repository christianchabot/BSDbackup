#ifndef _MACHINE_LOCK_H_
#define _MACHINE_LOCK_H_

#define SPINUNLOCK 1

#endif
