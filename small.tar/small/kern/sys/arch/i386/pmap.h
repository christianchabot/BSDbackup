#ifndef _MACHINE_PMAP_H_
#define _MACHINE_PMAP_H_

/*
System V Release 4 uses struct pageac for physical blocks of memory.

BSD 4.4 Lite uses struct pmap and pv_entry
*/

/*
Page directories must remain in core.
Page tables do not have to be in core (can be on disk).
*/

struct pmap {
	void *pm_vapd; /* KVA of page directory */
	unsigned long pm_pdrefcnt; /* pmap reference count. */
	unsigned long pm_refcnt; /* pmap reference count. */
	unsigned int pm_flags;
	int pm_lock;
};

struct pv_entry {
	/* Use this to find the offset into the page directory. */
	void *pv_va; /* virtual address of mapping. */
	void *pv_vae; /* end virtual address of mapping. */
	struct pmap *pv_pmap; /* pmap for where this entry resides. */
	int pv_flags;
};

#endif
