#ifndef _ISA_ISA_H_
#define _ISA_ISA_H_

/* Standard PC serial ports. */
#define IO_COM1 0x3f8 /* irq 4 */
#define IO_COM2 0x2f8 /* irq 3 */

/* Might be extras. */
#define IO_COM3 0x3e8 /* irq 4 */
#define IO_COM4 0x2e8 /* irq 3 */

#endif
