#ifndef _ISA_ISA_DEVICE_H_
#define _ISA_ISA_DEVICE_H_

struct isadev {
	struct isadriver *id_driver;
	int id_iobase; /* base i/o address. */
};

struct isadriver {
	int (*probe)(struct isadev *);
	int (*attach)(struct isadev *);
	const char *name;
};

#endif
