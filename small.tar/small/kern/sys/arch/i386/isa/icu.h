#ifndef _ISA_ICU_H_
#define _ISA_ICU_H_

/* Use T_386END because it is the same for all bus architectures. */
#define ICU_OFFSET 32 /* 0-31 are the processor defined exceptions. */
#define ICU_LEN    16 /* 32-47 are the ISA interrupts. */

#endif
