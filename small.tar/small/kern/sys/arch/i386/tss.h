#ifndef _MACH_TSS_H_
#define _MACH_TSS_H_

/*
i386 book: pg 484
A page fault exception should not happen during a task switch.
To ensure that this does not happen:
- Should not cross page boundary.
- Align the tss to 128 byte boundary.
- If the base of the tss is aligned on a 128-byte boundary,
the first 104 bytes cannot cross a page (4K) boundary.
*/
#define NBTSSALIGN 128
#define TSSALIGNMASK 0x7f

/* Task State Segment (defined by hardware). */
struct tss {
	int tss_link;
	int tss_esp0; 
	int tss_ss0;
	int tss_esp1;   /* Unused. */
	int tss_ss1;    /* Unused. */
	int tss_esp2;   /* Unused. */
	int tss_ss2;    /* Unused. */
	int tss_cr3;
	int tss_eip;
	int tss_eflags;
	int tss_eax;
	int tss_ecx;
	int tss_edx;
	int tss_ebx;
	int tss_esp;
	int tss_ebp;
	int tss_esi;
	int tss_edi;
	int tss_es;
	int tss_cs;
	int tss_ss;
	int tss_ds;
	int tss_fs;
	int tss_gs;
	int tss_ldt;
	int tss_ioopt; /* I/O Permission Bitmap Offset */
	/* 104 bytes that must be aligned to 128 byte boundary. */

	/* Extra bytes (up to 128) */
	char padding[128 - 104];
};

#endif
