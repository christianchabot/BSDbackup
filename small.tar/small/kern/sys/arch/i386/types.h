#ifndef _MACH_TYPES_H_
#define _MACH_TYPES_H_

/*
i386 dependent typedefs.
*/
#if sizeof int > 2
typedef int i386s16_t;
#else
typedef short i386s16_t;
#endif

#if sizeof short > 4
typedef short i386s32_t;
#elif sizeof int > 4
typedef int i386s32_t;
#else
typedef long i386s32_t;
#endif

#if sizeof unsigned int > 2
typedef unsigned int i386u16_t;
#else
typedef unsigned short i386u16_t;
#endif

#if sizeof unsigned short > 4
typedef unsigned short i386u32_t;
#elif sizeof unsigned int > 4
typedef unsigned int i386u32_t;
#else
typedef unsigned long i386u32_t;
#endif

#endif
