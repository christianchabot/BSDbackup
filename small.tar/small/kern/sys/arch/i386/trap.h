#ifndef _MACHINE_TRAP_H_
#define _MACHINE_TRAP_H_

#define T_DIVIDE    0  /* Integer divide exception. */
#define T_DEBUG     1  /* Debug Exception. */
#define T_NMI       2  /* NMI trap. */
#define T_BPTFLT    3  /* Breakpoint programmed trap. */
#define T_OFLOW     4  /* Overflow INTO trap. */
#define T_BOUND     5  /* Bounds check trap using bound instruction. */
#define T_ILLOP     6  /* Invalid opcode. */
#define T_DNA       7  /* Device not available. */
#define T_DOUBLEFLT 8  /* Double fault. */
#define T_FPSEGOVR  9  /* Coprocessor Segment overrun. */
#define T_TSSFLT    10 /* Invalid TSS fault. */
#define T_SEGNPFLT  11 /* Segment not present fault. */
#define T_STKFLT    12 /* Stack fault. */
#define T_PROTFLT   13 /* General protection fault. */
#define T_PAGEFLT   14 /* Page fault. */
#define T_RESERVED  15 /* Reserved */
#define T_FPOPFLT   16 /* Coprocessor operand fetch fault. */
#define T_ALIGNFLT  17 /* Alignment fault. */
#define T_MACHK     18 /* Machine check. */
#define T_XFTRAP    19 /* SIMD FP exception. */
#define T_386END    32 /* End of 386 defined exceptions. */

#define T_SYSCALL   128 /* System call. */


#endif
