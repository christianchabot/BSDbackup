#ifndef _MACH_FRAME_H_
#define _MACH_FRAME_H_

/* 80386 Trap frame stuff. */

struct trapframe {
	/* Only use these in the handler. */
	int tf_ds;
	int tf_es;

	/* Caller saved registers. Trap handler saves what it uses. */
	int tf_edx;
	int tf_ecx;
	int tf_eax;

	/* Defined by x86 hardware. */
	int tf_err; /* Trapno and error code. */
	int tf_eip;
	int tf_cs; /* Used to check if trap was caused by kernel or userspace. */
	int tf_eflags; /* Used to check if running in VM86 mode. */

	/* Used when crossing rings. */
	int tf_esp;
	int tf_ss;	
};

/* Might need v86 traps. */

#endif
