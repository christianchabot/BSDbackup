#ifndef _MSGBUF_H_
#define _MSGBUF_H_

#include <sys/param.h>

#define MSG_MAGIC 0x63061

struct msgbuf {
	long msg_magic;
	char *msg_rp; /* Read pointer */
	char *msg_wp; /* Write pointer */
	unsigned long msg_size;
};

#endif
