#ifndef _SYS_RESOURCE_H_
#define _SYS_RESOURCE_H_

#define RLIMIT_CORE
#define RLIMIT_CPU
#define RLIMIT_DATA
#define RLIMIT_FSIZE
#define RLIMIT_NOFILE
#define RLIMIT_STACK
#define RLIMIT_AS

struct rlimit {
	unsigned long coremax;
	unsigned long cpumax;
	unsigned long datamax;
	unsigned long filemax;
	unsigned long numberfilemax;
	unsigned long stackmax;
	unsigned long vmmax;
};

#endif
