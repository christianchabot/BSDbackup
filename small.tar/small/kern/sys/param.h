#ifndef _SYS_PARAM_H_
#define _SYS_PARAM_H_

#if ARCH == i386
#include <i386/param.h>
#else
#error "Unknown architecture.."
#endif

#define MSGBUFSIZE (2*NBPG)
#define KSTACKSIZE (2*NBPG)

#endif
