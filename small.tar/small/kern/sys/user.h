#ifndef _SYS_USER_H_
#define _SYS_USER_H_

#if ARCH == i386
#include <i386/pcb.h>
#else
#error "Unkown architecture.."
#endif

struct stat; /* Process Statistics. */
struct signal; /* Process signals. */
struct rlimit;

struct user {
	struct pcb *u_pcb; /* Pointer because it might need to be aligned. */

	struct stat *u_stat;
	/* If u_signal is null just use default ro signal value in kernel. */
	struct signal *u_signal;
	/* If p_rlimit is null just use default ro rlimit value in kernel. */
	struct rlimit *u_rlimit;
};

#endif
