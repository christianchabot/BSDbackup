#ifndef _SYS_SOCKET_H_
#define _SYS_SOCKET_H_

/* Socket functions. */

#endif
