#ifndef _REBOOT_H_
#define _REBOOT_H_

/* BSD arguments. */
#define RB_AUTOBOOT 0x000
#define RB_ASKNAME  0x001 /* Prompt for a filename to bootstrap. */
#define RB_SINGLE   0x002 /* Bootstrap to single-user operation. */
#define RB_NOSYNC   0x004 /* Do not sync before rebooting. */
#define RB_HALT     0x008 /* Do not reboot just halt. */
#define RB_INITNAME 0x010 /* Use the name given instead of /sbin/init. */
#define RB_DFLTROOT 0x020 /* Use compiled-in rootdev */
#define RB_KDB      0x040 /* Give control to kernel debugger. */
#define RB_RDONLY   0x080 /* Mount root filesystem read-only */
#define RB_DUMP     0x100 /* Dump kernel memory before reboot. */

#endif

