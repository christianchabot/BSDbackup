#ifndef _SYS_ERRNO_H_
#define _SYS_ERRNO_H_

#define ENXIO 6 /* Device not configured. */

#endif
