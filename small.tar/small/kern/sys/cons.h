#ifndef _SYS_CONS_H_
#define _SYS_CONS_H_

void cninit(void);

#endif
