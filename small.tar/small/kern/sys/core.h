#ifndef _CORE_H_
#define _CORE_H_

/* The open group leaves the core file format open to implementation. */

/* We are just going to use the elf format with a few extra symbols. */

#endif
