#ifndef _SIGNAL_H_
#define _SIGNAL_H_

struct mcontext;

struct ucontext {
	void *uc_link; /* Pointer to the context that is resumed when this context returns. */
	void *ucstack; /* The stack used by this context. */
	int uc_sigmask; /*The set of signals that are blocked when this context is active. */
	struct mcontext *uc_mcontext; /* Machine specific representation of the saved context. */
};

struct sigaction {
	int tmp;
};

struct signal {
	int tmp; /* Remove later. */
};

#endif
