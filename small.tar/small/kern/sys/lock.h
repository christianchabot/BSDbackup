#ifndef _LOCK_H_
#define _LOCK_H_

#if ARCH == i386
#include <i386/lock.h>
#else
#error "Unkown architecture.."
#endif

void spinlock(int *lock);
void spinunlock(int *lock);

/* Should make a fair version for spinlocks. */

#endif
