#ifndef _MOUNT_H_
#define _MOUNT_H_

/* Structures and defines used for mounting file systems. */

#endif
