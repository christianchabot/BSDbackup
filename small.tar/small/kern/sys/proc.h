#ifndef _SYS_PROC_H_
#define _SYS_PROC_H_

#include <sys/param.h>
#include <sys/user.h>

/* Define NPROC by how many procs can fit in a page. */
#define NPROC (NBPG/sizeof(struct proc))

struct cpuinfo; /* Process cpu statistics. */
struct vmspace;
struct filedesc; /* Process file descriptors. */

/* Everything not static is allocated later, nothing is cached. */
struct proc {
	/* Things that are needed by the process on creation. */
	struct cpuinfo *p_cpuinfo; /* Important for scheduling. */
	struct vmspace *p_vmspace;

	/* End of needed at creation time. */

	/* Maybe needed on creation. */
	struct filedesc *p_fd;

	/* Stuff that is allocated later. */
	/* If p_user is null just use default ro signal value in kernel. */
	/* If p_rlimit is null just use default ro rlimit value in kernel. */
	struct user *p_user;

	/* Static values. */
	struct proc **p_proc; /* Pointer into proctab use p_proc - proctab = pid */

	/* Not static values. */
	struct proc *p_parent;
	/* Need a linked list of children. */
	int p_flags;

	/* User id as int for now */
	int p_uid;
};

/*
Notes:
	If these do not fit nicely in a page, no worries some architectures it might not.

	struct proc:
		sizeof(struct proc) = 32; // This will grow slightly.
		waste bytes in pointers: 8

	Other OS's:
		openbsd: sizeof(struct proc) = ~209; // Everything is cached in structure.

	struct vmspace:
		sizeof(struct vmspace) = 16; // Fits 256 into 1 4096 page.
		waste bytes in pointers: 12

	Other OS's:
		openbsd: sizeof(struct proc)


	struct user:
		sizeof(struct user) = 16; // Fits 256 into 1 4096 page.
		waste bytes in pointers:

	Other OS's:
		openbsd: sizeof(struct proc)
*/
#endif
