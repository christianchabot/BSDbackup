#ifndef _SYS_SYSLOG_H_
#define _SYS_SYSLOG_H_

/* Kernel log functions. */

#endif
