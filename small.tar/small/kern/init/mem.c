
/* Initialize the memory allocator. */
void
meminit(void)
{
	return;
}

/* Initialize the terminal I/O facilities. */
void
cinit(void)
{
	return;
}

