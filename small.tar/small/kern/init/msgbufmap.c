#include <sys/param.h>

/*
I think the reason the msgbuf was mapped to the end of memory is
because it can be easily found using /dev/kmem but now we have
/dev/log so its less important..

For now just leave the msgbuf mapped into our data segment.
Expose /dev/log to userspace.
*/
struct {
	unsigned char buf[MSGBUFSIZE];
} msgbuf;

/* Maps the message buffer into memory. */
void
msgbufmap(void)
{
	return;
}
