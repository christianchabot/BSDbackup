
/*
- Initialize the runtime stack
- Identify the type of CPU on which the system is executing
- Calculate the amount of physical memory on the machine
- Enable the virtual-address-translation hardware
- Initialize the memory-management hardware
- Crafting the hardware context for process 0
- Invoking the initial C-based entry point of the system
- Virtual-memory mapping
- Set up virtual memory page tables
- Configure io devices
- Start up other CPUs
*/

/* Machine dependant initialization */
void
initmach(void)
{
}

/*
Notes:
- Boot starts the kernel with the interrupt priority set at its highest level so that
all hardware interrupts are blocked.
- The hardware address-translation facility is disabled so that all memory references
are to physical memory locations.
*/
