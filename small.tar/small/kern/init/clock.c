unsigned int lbolt; /* BSD 1 per second sleep variable. */
