#include <sys/proc.h>
#include <vm/vm.h>

/* Here so we do not mess with std C. */
//#define main kmain

void initmach(void);

/* Arguments from bootloader. */
unsigned int boothowto;
int bootdev, bootargc;
void *bootargv;

void
main(void *framep)
{
	for (;;)
		;

	/* Not reached */
}

#undef main

/* Start up */
void
startup(void *kend)
{
	return;
}
