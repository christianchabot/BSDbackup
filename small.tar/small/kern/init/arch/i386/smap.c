
struct SMAPentry {
	unsigned int basel;
	unsigned int baseh;
	unsigned int lenl;
	unsigned int lenh;
	unsigned int type;
	unsigned int acpi;
};


