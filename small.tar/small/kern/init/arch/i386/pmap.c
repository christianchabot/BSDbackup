#include <i386/pmap.h>
#include <i386/lock.h>
#include <sys/param.h>

extern char end[]; /* End of kernel data provided by linker. */
extern char text[]; /* Start of kernel text provided by linker. */
extern char data[]; /* Start of kernel data provided by linker. */

/* Initial state of kernel mapping. */
struct pmap kernel_pmap = {
	end + KSTACKSIZE, /* Entry kernel page directory location. */
	1, /* page directory reference count is 1 */
	1, /* pmap reference count is 1 */
	0, /* Flags. */
	SPINUNLOCK
};

/* Wired down kernel mappings. */
struct pv_entry kernel_text = {
	text,
	data,
	&kernel_pmap
}, kernel_data = {
	data,
	end,
	&kernel_pmap
}, kernel_stack = {
	end,
	end + KSTACKSIZE,
	&kernel_pmap
};

/* BSD book. */
/* System initialization and startup. */
void
pmap_bootstrap(void)
{

}

void
pmap_bootstrap_alloc(void)
{

}

/* called from vm_init() */
void
pmap_init(void)
{

}

/* Allocation and deallocation of mappings of physical to virtual pages. */
void
pmap_enter(struct pmap *pmap, void *sva, void *eva, int flags)
{
	
}

void
pmap_remove(void)
{

}

/* Change of access protections and other attributes of mappings. */
void
pmap_change_wiring(void)
{

}

void
pmap_page_protect(void)
{

}

void
pmap_protect(void)
{

}

/* Maintenance of physical page-usage information. */
void
pmap_clear_modify(void)
{

}

void
pmap_clear_reference(void)
{

}

void
pmap_is_modified(void)
{

}

void
pmap_is_referenced(void)
{

}

/* Initialization of physcial pages. */
void
pmap_copy_page(void)
{

}

void
pmap_zero_page(void)
{

}

/* Management of internal data structures. */
struct pmap *
pmap_create(void)
{

}

void
pmap_reference(void)
{

}

void
pmap_destroy(void)
{

}

void
pmap_pinit(void)
{

}

void
pmap_release(void)
{

}

void
pmap_copy(void)
{

}

void
pmap_pageable(void)
{

}

void
pmap_collect(void)
{

}

void
pmap_update(void)
{

}
