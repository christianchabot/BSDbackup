#include <i386/frame.h>

/* Other trap frame handlers. */

/* Generic trap handler. */
void
trap(struct trapframe *tf)
{
	return;
}
