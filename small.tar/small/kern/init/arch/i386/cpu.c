#include <i386/cpu.h>

struct cpu_info cpus[NCPU];
