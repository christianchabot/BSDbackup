#include <i386/isa/isa_device.h>
#include <i386/isa/isa.h>

#include <sys/systm.h>

extern int comprobe(struct isadev *);
extern int comattach(struct isadev *);

struct isadev *comp = (void *) 0;

static const struct isadriver com1dr = {
	comprobe,
	comattach,
	"COM1 Serial Device Driver"
}, com2dr = {
	comprobe,
	comattach,
	"COM2 Serial Device Driver"
}, com3dr = {
	comprobe,
	comattach,
	"COM3 Serial Device Driver"
}, com4dr = {
	comprobe,
	comattach,
	"COM4 Serial Device Driver"
};

static struct isadev coms[] = {
	{(struct isadriver *) &com1dr, IO_COM1},
	{(struct isadriver *) &com2dr, IO_COM2},
	{(struct isadriver *) &com3dr, IO_COM3},
	{(struct isadriver *) &com4dr, IO_COM4}
};

int
comconsinit(void)
{
	struct isadev *end = coms + 4, *ptr;

	/* Setup com ports. */
	for (ptr = coms; ptr < end; ++ptr) {
		int tmp = ptr->id_driver->probe(ptr);
		printf("%s%sfound at port %x\n", ptr->id_driver->name, tmp ? " not" : " ", ptr->id_iobase);
		if (!tmp) {
			if (!ptr->id_driver->attach(ptr)) {
				/* Serial port to dump too. */
				if (!comp)
					comp = ptr;
			} else
				printf("Failed to attach %s\n", ptr->id_driver->name);
		}
	}
}
