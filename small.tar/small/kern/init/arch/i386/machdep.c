#include <i386/page.h>
#include <i386/pcb.h>
#include <i386/segments.h>

#include <sys/param.h>

#include <dev/cons.h>

extern void initdesctabs(void);
extern char end[]; /* End of kernel data section */

void *avail_end = (void *) 0; /* End of physical memory. */

struct pcb pcb0 = { /* alignment is specified in locore.S */
	{ /* struct tss pcb_tss */
		0, /* link */
		(int) (end + KSTACKSIZE), /* esp0 = entry kernel stack */
		GSEL(GDATA_SEL, SEL_KPL), /* ss0 = kernel global data descriptor */
		0, /* esp1 = unused */
		0, /* ss1 = unused */
		0, /* esp2 = unused */
		0, /* ss2 = unused */
		(int) (end + KSTACKSIZE), /* cr3 = entry kernel page directory. */
		0, /* eip should point to start of scheduler text segment? */
		0, /* eflags */
		0, /* eax */
		0, /* ecx */
		0, /* edx */
		0, /* ebx */
		0, /* esp */
		0, /* ebp */
		0, /* esi */
		0, /* edi */
		0, /* es */
		0, /* cs */
		0, /* ss */
		0, /* ds */
		0, /* fs */
		0, /* gs */
		0 /* ldt should point to ldt? */
	}
};

extern void consinit(void);

/* Initialize the system console. */
/* Setup msgbuf at end of physcial memory. */
/* Initialize the DDB if it is compiled into the kernel. */
/* Initialzie the TSS. */
/* Prepare the LDT. */
/* Setup proc0's pcb. */
void
init386(void *first_avail)
{
	initdesctabs(); /* Setup the hardware descriptor tables. */

	/* Initialize the system console for early panic. */
	consinit();

	/* Setup the msgbuf to last page of physical memory. */

	/* Setup physical memory allocator. */
}
