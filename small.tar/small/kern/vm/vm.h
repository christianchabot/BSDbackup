#ifndef _VM_MAP_H_
#define _VM_MAP_H_

struct pmap; /* Machine dependent physical map. */

struct vm_map_entry {
	struct vm_map_entry *vme_left, *vme_right;
	void *vme_start;
	void *vme_end;
	int vme_flags;
};

struct vm_map {
	struct pmap *vm_pmap;
	struct vm_map_entry *vm_header;
	unsigned int vm_refcnt;
	int vm_lock;
};

struct vmspace {
	struct vm_map *vs_map;
	struct pmap *vs_pmap;
	unsigned int vs_refcnt;
	int vs_lock;
};

#endif

