#include <stdio.h>

#define NBPG 4096
#define PDSHIFT 22
#define PTSHIFT 12
#define PGMASK (NBPG - 1)

#define PGTRUNC(addr) (addr & ~PGMASK)
#define PGROUND(addr) (addr + PGMASK & ~PGMASK)

int
main(int argc, char *argv[])
{
	printf("%x: >> %d = offset %d\n", 0xf0000000, PDSHIFT, 0xf0000000 >> PDSHIFT);
	printf("%x: >> %d = offset %d\n", 0x100000, PTSHIFT, 0x100000 >> PTSHIFT);
	printf("%x: >> %d = offset %d\n", 0x100000, PTSHIFT, 0x100000 >> PTSHIFT);

	printf("%x: round up %x\n", 0x100000, PGROUND(0x100000));
	printf("%x: round up %x\n", 0x100001, PGROUND(0x100001));
	printf("%x: round down %x\n", 0x100000, PGTRUNC(0x100000));
	printf("%x: round down %x\n", 0x100001, PGTRUNC(0x100001));
	printf("4M >> 22 - 12 = %x\n", (4*1024*1024) >> (22 - 12));
	return 0;
}
