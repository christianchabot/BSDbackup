#include <stdarg.h> /* Provided by the compiler. */
#include <stdio.h>

#include <unistd.h>

#define CHAR  1
#define SHORT 2
#define INT   0
#define LONG  3
#define VOID  4

const static int

struct flag {
	int base : 5;
	int size : 3;
	int tolow : 1;
	int sign : 1;
	int p : 1;

};

union value {
	void *p;
	const char *s;
	long l;
	int d;
	short h;
	char hh;
};

/* Hacker's delight. */
static unsigned long
div10(unsigned long n)
{
	unsigned long r, q;
	q = (n >> 1) + (n >> 2);
	q = q + (q >> 4);
	q = q + (q >> 8);
	q = q + (q >> 16);
	q = q >> 3;
	r = n - ((q << 2) + q << 1);
	return q + (r > 9);
}

static unsigned long
mod10(unsigned long n)
{
	unsigned long r = n & 1;
	n >>= 1;

	n = (n >> 16) + (n & 0xffff);
	n = (n >> 8) + (n & 0xff);
	n = (n >> 4) + (n & 0xf);
	if (n > 14)
		n -= 15;

	if (n > 4)
		n -= 5;
	if (n > 4)
		n -= 5;
	return r + (n << 1);
}

static void
printint(void (*kputc) (int), union value *val, struct flag *flags)
{
	static const char dig[] = {
		'0', '1', '2', '3', '4', '5', '6', '7', '8', '9', 'a', 'b', 'c', 'd', 'e', 'f',
		'0', '1', '2', '3', '4', '5', '6', '7', '8', '9', 'A', 'B', 'C', 'D', 'E', 'F'
	};
	long tmp;
	int shift, toupper;
	/*
	Largets 64 bit octal number is 21.3 digits so round up to 24.
	Largest 64 bit number is 20 digits.
	Largest 32 bit number is 10 digits.
	*/
	char buf[24], *ptr = buf;

	switch (flags.size) {
	case INT:
		tmp = val.d;
		break;
	case CHAR:
		tmp = val.hh;
		break;
	case SHORT:
		tmp = val.h;
		break;
	case LONG:
		tmp = val.l;
		break;
	case VOID:
		tmp = 
	}

	switch (flags.base) {
	case 16:
		shift = ((flags.size == LONG ? sizeof(long) : sizeof(int)) << 3) - 4;

		/* Do not print leading 0's. */
		if (!(flags.size & PAD0))
			for (; shift > 0; shift -= 4)
				if (val >> shift & 0xf)
					break;

		toupper = flags.size & TOLOWER ? 0 : 16;
		for (; shift > 0; shift -= 4)
			kputc(dig[toupper + (val >> shift & 0xf)]);
		kputc(dig[toupper + (val & 0xf)]);
		break;
	case 10:
		if (flags & SIGNED && val < 0) {
			kputc('-');
			val = -val;
		}

		do {
			/* Should I just use the / and % operators? */
			/* *ptr++ = dig[mod10(val)];
			val = div10(val); */
			*ptr++ = dig[val % 10];
			val /= 10;
		} while (val);

		do {
			kputc(*--ptr);
		} while (ptr > buf);
		break;
	case 8:
		do {
			*ptr++ = dig[val & 0x7];
			val >>= 3;
		} while (val);

		do {
			kputc(*--ptr);
		} while (ptr > buf);
		break;
	default:
		break;
	}
}

static void
kvprintf(void (*kputc) (int), const char *fmt, va_list ap)
{
	const char *end;
	for (end = fmt; *end; ++end) {
		union value val;
		struct flag flags = {0};
		if (*end != '%') {
			kputc(*end);
			continue;
		}

		switch (*++end) {
		case 'l':
			flags.size = LONG;
			++end;
			break;
		case 'h':
			flags.size = SHORT;
			if (*(end + 1) == 'h') {
				flags.size = CHAR;
				++end;
			}

			++end;
			break;
		}

		switch (*end) {
		case 'p':
			if (flags.size != INT)
				break;
			flags.p = 1;
			flags.size = VOID;
		case 'x':
			flags.tolow = 1;
		case 'X':
			flags.base += 6;
		case 'd':
			flags.sign = 1;
		case 'u':
			flags.base += 2;
		case 'o':
			flags.base += 8;

			switch (flags.size) {
			case INT:
				val.d = va_arg(ap, int);
				break;
			case CHAR:
				val.hh = (char) va_arg(ap, int);
				break;
			case SHORT:
				val.h = (short) va_arg(ap, int);
				break;
			case LONG:
				val.l = va_arg(ap, long);
				break;
			case VOID:
				val.p = va_arg(ap, void *);
			};
			printint(kputc, &val, flags);
			break;
		case 's':
			val.s = va_arg(ap, const char *);
			if (!val.s)
				val.s = "(null)";
			{
				const char *tmp = &val.s;
				do {
					kputc(*tmp);
				} while (*++tmp);
			}
			break;
		case '%':
			kputc('%');
		default:
			break;
		}

		if (!*end)
			break;
	}
}

void
kprintf(void (*putc) (int), const char *fmt, ...)
{
	va_list ap;
	va_start(ap, fmt);
	kvprintf(putc, fmt, ap);
	va_end(ap);
}

int
main(int argc, char *argv[])
{
	/*
	kprintf(putchar, "dec: %d hex: %x %X mem: %p oct: %o\n", 0xdeadbeef, 0xdeadbeef, 0xdeadbeef, 0xdeadbeef, 0xdeadbeef);
	kprintf(putchar, "dec: %d hex: %x %X mem: %p oct: %o\n", -1, -1, -1, -1, -1);
	kprintf(putchar, "dec: %d hex: %x %X mem: %p oct: %o\n", 0, 0, 0, 0, 0);
	kprintf(putchar, "dec: %ld hex: %lx %lX mem: %p oct: %lo\n", (long) 0xb00bdeadbeef, (long) 0xb00bdeadbeef, (long) 0xb00bdeadbeef, (long) 0xb00bdeadbeef, (long) 0xb00bdeadbeef);
	*/
	printf("%-u test\n", 0x69);
	return 0;
}
