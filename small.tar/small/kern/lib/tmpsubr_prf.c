#include <stdarg.h> /* Provided by the compiler. */
#include <stddef.h> /* Provided by the compiler. */

#include <stdio.h>
#undef putc

#include <unistd.h>

#define INT   0
#define CHAR  1
#define SHORT 2
#define LONG  3
#define VOID  4

#define NONE  0x0
#define SPACE 0x1
#define PLUS  0x2
#define NUMS  0x4
#define ZERO  0x8
#define MINUS 0x10

#define SETVALUE(val, flag, sign)\
	do {\
		switch (flag.len) {\
		case CHAR:\
			val.hh = (sign char) va_arg(ap, sign int);\
			break;\
		case SHORT:\
			val.h = (sign short) va_arg(ap, sign int);\
			break;\
		case INT:\
			val.d = va_arg(ap, sign int);\
			break;\
		case LONG:\
			val.l = va_arg(ap, sign long);\
			break;\
		}\
	} while (0)

struct flag {
	unsigned int base : 5;
	unsigned int flag : 5;
	unsigned int len  : 3;
	unsigned int low  : 1;
	unsigned int sign : 1;
	unsigned int width;
};

union value {
	void *p;
	long l;
};

static void
pad(void (*putc) (int), unsigned int count, int pad)
{
	for (; count; --count)
		putc(pad);
}

static void
dumphex(void (*putc) (int), union value *val, struct flag *flags)
{
	static const char digit[] = "0123456789abcdef0123456789ABCDEF"; 
	const unsigned char *bytes, *base;

	switch (flags->len) {
	case CHAR:
		base = (const char *) val + offsetof(union value, hh);
		bytes = (const char *) base + sizeof(unsigned char) - 1;
		break;
	case SHORT:
		base = (const char *) val + offsetof(union value, h);
		bytes = (const char *) base + sizeof(unsigned short) - 1;
		break;
	case INT:
		base = (const char *) val + offsetof(union value, d);
		bytes = (const char *) base + sizeof(unsigned int) - 1;
		break;
	case LONG:
		base = (const char *) val + offsetof(union value, l);
		bytes = (const char *) base + sizeof(unsigned long) - 1;
		break;
	case VOID:
		base = (const char *) val + offsetof(union value, p);
		bytes = (const char *) base + sizeof(void *) - 1;
		break;
	}

	for (; bytes > base; --bytes)
		putc(digit[*bytes >> 4]), putc(digit[*bytes & 0xf]);
	putc(digit[*bytes >> 4]), putc(digit[*bytes & 0xf]);
}

static void
print(void (*putc) (int), union value *val, struct flag *flags)
{
	static const char digit[] = "0123456789abcdef0123456789ABCDEF"; 
	const char *nump = "x0" + 2;
	unsigned padsz, numsz = 2, i;
	int shift = 4, mask = 0xf, pbyte = '0', tolow;
	char buf[24], *ptr = buf;

	long tmp = val->l;
	switch (flags->base) {
	case 0: /* Pointer */
		break;
	case 8: /* Octal */
		shift = 3;
		mask = 0x7;
		numsz = 1;
	case 16: /* Hexadecimal */
		if (flags->flag & MINUS && !(flags->flag & SPACE))
			flags->flag |= SPACE;

		tolow = flags->low ? 0 : 16;
		do {
			*ptr++ = digit[tolow + (tmp & mask)];
			tmp >>= shift;
		} while (tmp);

		if (val->l && !(flags->flag & SPACE) && flags->flag & NUMS)
			for (i = numsz; i; --i)
				putc(*--nump);
		break;
	case 10: /* Decimal */
		numsz = 0;
		do {
			*ptr++ = digit[tmp % 10];
			tmp /= 10;
		} while (tmp);
	}

	/* Padding here. */
	padsz = (ptr - buf) + numsz;
	if (!(flags->flag & MINUS) && padsz < flags->width)
		pad(putc, flags->width - padsz, flags->flag & SPACE ? ' ' : '0');

	if (val->l && flags->flag & SPACE && flags->flag & NUMS)
		for (i = numsz; i; --i)
			putc(*--nump);
	do {
		putc(*--ptr);
	} while (ptr > buf);

	if (flags->flag & MINUS && padsz < flags->width)
		pad(putc, flags->width - padsz, flags->flag & SPACE ? ' ' : '0');
}

static void
kvprintf(void (*putc) (int), const char *fmt, va_list ap)
{
	static const union value vzero;
	static const struct flag fzero;
	for (; *fmt; ++fmt) {
		union value val;
		struct flag flags;
		if (*fmt != '%') {
			putc(*fmt);
			continue;
		}

		val = vzero;
		flags = fzero;
	flag:
		switch (*++fmt) {
		case ' ':
			flags.flag |= SPACE;
			goto flag;
		case '+':
			flags.flag |= PLUS;
			goto flag;
		case '#':
			flags.flag |= NUMS;
			goto flag;
		case '0':
			flags.flag |= ZERO;
			goto flag;
		case '-':
			flags.flag |= MINUS;
			goto flag;
		}

		/* Width */
		switch (*fmt) {
		case '0': case '1': case '2': case '3': case '4':
		case '5': case '6': case '7': case '8': case '9':
			flags.width = *fmt++ - '0';
		}

	width:
		switch (*fmt) {
		case '0': case '1': case '2': case '3': case '4':
		case '5': case '6': case '7': case '8': case '9':
			flags.width = ((flags.width << 2) + flags.width << 1);
			flags.width = *fmt++ - '0';
			if (flags.width <= 16)
				goto width;
		}

		/* Length */
		switch (*fmt) {
		case 'l':
			flags.len = LONG;
			++fmt;
			break;
		case 'h':
			flags.len = SHORT;
			if (*(fmt + 1) == 'h') {
				flags.len = CHAR;
				++fmt;
			}
			++fmt;
			break;
		}

		/* Conversion specifier */
		switch (*fmt) {
		case 'p':
			if (flags.len == 0 && !(flags.flag & ~MINUS)) {
				val.p = va_arg(ap, void *);
				print(putc, &val, &flags);
			}
			break;
		case 'x':
			flags.low = 1;
			dumphex(putc, &val, &flags);
			break;
		case 'X':
			flags.base += 6;
		case 'd':
			flags.sign = 1;
			flags.base += 2;
		case 'u':
		case 'o':
			flags.base += 8;
			if (flags.base == 10) {
				if (flags.sign)
					SETVALUE(val, flags, );
				else
					SETVALUE(val, flags, unsigned);
			} else
				SETVALUE(val, flags, unsigned);
			print(putc, &val, &flags);
			break;
		case 's':
			if (flags.len == 0 && !(flags.flag & ~MINUS)) {
				
			}
			break;
		case '%':
			if (flags.len == 0 && flags.flag == 0 && flags.width == 0)
				putc('%');
			break;
		default:
			if (*fmt)
				putc(*fmt);
			break;
		case '\0':
			return;
		}
	}
}

void
kprintf(void (*putc) (int), const char *fmt, ...)
{
	va_list ap;
	va_start(ap, fmt);
	kvprintf(putc, fmt, ap);
	va_end(ap);
}

int
main(int argc, char *argv[])
{
	kprintf((void (*)(int)) putchar, "Test: %0x|\n", 0xdead);
	kprintf((void (*)(int)) putchar, "Test: %#08X|\n", 0xdead);
	kprintf((void (*)(int)) putchar, "Test: %# 8X|\n", 0xdead);
	kprintf((void (*)(int)) putchar, "Test: %#- 8X|\n", 0xdead);
	kprintf((void (*)(int)) putchar, "Test: %#-08X|\n", 0xdead);
	//kprintf((void (*)(int)) putchar, "Test: %%\n", 0xdead);
	//kprintf((void (*)(int)) putchar, "Test: %h%\n", 0xdead);
	return 0;
}
