#include <stdio.h>

int
main(int argc, char *argv[])
{
	printf("Test: %0#8x|\n", 0xdead);
	printf("Test: %##8x|\n", 0xdead);
	printf("Test: %# 8X|\n", 0xdead);
	printf("Test: %#- 8X|\n", 0xdead);
	printf("Test: %#-08X|\n", 0xdead);
	return 0;
}
