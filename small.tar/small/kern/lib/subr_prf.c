#include <stdarg.h> /* Provided by the compiler. */
#include <stddef.h> /* Provided by the compiler. */

#include <stdio.h>
#undef putc

#include <unistd.h>

#define NONE  0x0
#define SPACE 0x1
#define PLUS  0x2
#define NUMS  0x4
#define ZERO  0x8
#define MINUS 0x10

enum {INT, CHAR, SHORT, LONG, VOID};

union value {
	unsigned int i;
	unsigned char hh;
	unsigned short h;
	unsigned long l;
	void *p;
};

struct flag {
	unsigned int base : 5;
	unsigned int len  : 3;
	unsigned int flag : 5;
	unsigned int low  : 1;
	unsigned int sign : 1;
	unsigned int width;
};

static const struct {
	unsigned int boff;
	unsigned int eoff;
} ltab[8] = {
	offsetof(union value, i),
	sizeof(int) - 1,
	offsetof(union value, hh),
	sizeof(char) - 1,
	offsetof(union value, h),
	sizeof(short) - 1,
	offsetof(union value, l),
	sizeof(long) - 1,
	offsetof(union value, p),
	sizeof(void *) - 1
};

static unsigned long
dumphex(void (*putc) (int), union value *val, struct flag *flags)
{
	static const char digit[] = "0123456789ABCDEF0123456789abcdef"; 
	const unsigned char *base = (const unsigned char *) val + ltab[flags->len].boff, *end;
	unsigned long r = 0;
	int upper = flags->low << 4;

	/* Skip zeros. */
	end = base + ltab[flags->len].eoff;
	if (!(flags->flag & ZERO))
		for (; end > base; --end)
			if (*end) {
				if (*end >> 4)
					putc(digit[upper + (*end >> 4)]);
				if (*end & 0xf)
					putc(digit[upper + (*end & 0xf)]);
				--end;
				break;
			}

	for (; end > base; --end) {
		putc(digit[upper + (*end >> 4)]);
		putc(digit[upper + (*end & 0xf)]);
		
	}

	if (*end >> 4)
		putc(digit[upper + (*end >> 4)]);
	putc(digit[upper + (*end & 0xf)]);
}

static void
kvprintf(void (*putc) (int), const char *fmt, va_list ap)
{
	static const union value vzero;
	static const struct flag fzero;
	for (; *fmt; ++fmt) {
		union value val;
		struct flag flags;
		if (*fmt != '%') {
			putc(*fmt);
			continue;
		}

		val = vzero;
		flags = fzero;
	flag:
		switch (*++fmt) {
		case ' ':
			flags.flag |= SPACE;
			goto flag;
		case '+':
			flags.flag |= PLUS;
			goto flag;
		case '#':
			flags.flag |= NUMS;
			goto flag;
		case '0':
			flags.flag |= ZERO;
			goto flag;
		case '-':
			flags.flag |= MINUS;
			goto flag;
		}

		/* Width */
		switch (*fmt) {
		case '0': case '1': case '2': case '3': case '4':
		case '5': case '6': case '7': case '8': case '9':
			flags.width = *fmt++ - '0';
		}

	width:
		switch (*fmt) {
		case '0': case '1': case '2': case '3': case '4':
		case '5': case '6': case '7': case '8': case '9':
			flags.width = ((flags.width << 2) + flags.width << 1);
			flags.width = *fmt++ - '0';
			if (flags.width <= 16)
				goto width;
		}

		/* Length */
		switch (*fmt) {
		case 'l':
			flags.len = LONG;
			++fmt;
			break;
		case 'h':
			flags.len = SHORT;
			if (*(fmt + 1) == 'h') {
				flags.len = CHAR;
				++fmt;
			}
			++fmt;
			break;
		}

		/* Conversion specifier */
		switch (*fmt) {
		case 'p':
			flags.len = VOID;
			flags.low = 1;
			val.p = (void *) va_arg(ap, void *);
			dumphex(putc, &val, &flags);
			break;
		case 'x':
			flags.len = INT;
			flags.low = 1;
			val.i = (unsigned int) va_arg(ap, unsigned int);
			dumphex(putc, &val, &flags);
			break;
		case 'X':
			flags.len = INT;
			flags.low = 0;
			val.i = (unsigned int) va_arg(ap, unsigned int);
			dumphex(putc, &val, &flags);
			break;
			flags.base += 6;
		case 'd':
			flags.sign = 1;
			flags.base += 2;
		case 'u':
		case 'o':
			flags.base += 8;
			break;
		case 's':
			if (flags.len == 0 && !(flags.flag & ~MINUS)) {
				
			}
			break;
		case '%':
			if (flags.len == 0 && flags.flag == 0 && flags.width == 0)
				putc('%');
			break;
		default:
			if (*fmt)
				putc(*fmt);
			break;
		case '\0':
			return;
		}
	}
}

void
kprintf(void (*putc) (int), const char *fmt, ...)
{
	va_list ap;
	va_start(ap, fmt);
	kvprintf(putc, fmt, ap);
	va_end(ap);
}

int
main(int argc, char *argv[])
{
	kprintf((void (*)(int)) putchar, "Test: %x|\n", 0xdead);
	kprintf((void (*)(int)) putchar, "Test: %0x|\n", 0xdead);
	kprintf((void (*)(int)) putchar, "Test: %X|\n", 0xdead);
	kprintf((void (*)(int)) putchar, "Test: %0X|\n", 0xdead);
	kprintf((void (*)(int)) putchar, "Test: %p|\n", 0xdead);
	/*
	kprintf((void (*)(int)) putchar, "Test: %#08X|\n", 0xdead);
	kprintf((void (*)(int)) putchar, "Test: %# 8X|\n", 0xdead);
	kprintf((void (*)(int)) putchar, "Test: %#- 8X|\n", 0xdead);
	kprintf((void (*)(int)) putchar, "Test: %#-08X|\n", 0xdead); */
	//kprintf((void (*)(int)) putchar, "Test: %%\n", 0xdead);
	//kprintf((void (*)(int)) putchar, "Test: %h%\n", 0xdead);
	return 0;
}
