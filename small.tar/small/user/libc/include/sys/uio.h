#ifndef _UIO_H_
#define _UIO_H_

struct fdvec {
	ssize_t retval;
	int fd;
};

/*
Read from multiple file descriptors into the given buffer concatenated.
Returns total bytes or -1 on error.
*/
ssize_t
readcat(void *buf, struct fdvec *, int fdvcnt)
{

}

/* This will be the structure for the kernel iovec structure. */
/* The user of this api needs to know ahead of time */
struct iovec {
	void *iov_base;
	unsigned long iov_len;
	ssize_t retval;
	int fd; 
	/*
	Return value used by the kernel.
	If this is -1 means error.

	*/
};

/*
ssize_t
readv(int fd, struct iovec *iov, int iovcnt)
{
	return syscall(SYS_readv, fd, iov, iovcnt);
}

TODO: How kernel readv should work.
Returns the total bytes transfered into the buffer.
ssize_t
mreadv(struct iovec *iov, int iovcnt)
{
	
}
*/

#endif
