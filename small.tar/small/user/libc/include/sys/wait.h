#ifndef _WAIT_H_
#define _WAIT_H_

int wait(void);

#endif
