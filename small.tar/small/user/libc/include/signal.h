#ifndef _SIGNAL_H_
#define _SIGNAL_H_

int kill(int);

#endif
