#ifndef _STDLIB_H_
#define _STDLIB_H_

void *free(void *);
void *malloc(unsigned int);

#endif
