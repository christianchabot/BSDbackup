#include <string.h>

int
strcoll(const char *s1, const char *s2)
{
	return 0; /* TODO */
}
