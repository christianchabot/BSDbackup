#include <string.h>

size_t
strxfrm_l(char *restrict s1, const char *restrict s2, size_t n, locale_t locale)
{
	return 0; /* TODO */
}
