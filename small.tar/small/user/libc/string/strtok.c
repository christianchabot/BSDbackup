#include <string.h>

char *
strtok(char *restrict s, const char *restrict sep)
{
	return NULL; /* TODO */
}
