#include <string.h>

char *
strtok(char *restrict s, const char *restrict sep)
{
	return NULL; /* TODO */
}

char *
strtok_r(char *restrict s, const char *restrict sep, char **restrict state)
{
	return NULL; /* TODO */
}

size_t
strxfrm(char *restrict s1, const char *restrict s2, size_t n)
{
	return 0; /* TODO */
}

size_t
strxfrm_l(char *restrict s1, const char *restrict s2, size_t n, locale_t locale)
{
	return 0; /* TODO */
}
