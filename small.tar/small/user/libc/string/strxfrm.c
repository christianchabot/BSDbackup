#include <string.h>

size_t
strxfrm(char *restrict s1, const char *restrict s2, size_t n)
{
	return 0; /* TODO */
}
