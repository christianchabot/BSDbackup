#include <string.h>

int
strerror_r(int errnum, char *strerrbuf, size_t buflen)
{
	return 0; /* TODO */
}
