#include <string.h>

char *
strtok_r(char *restrict s, const char *restrict sep, char **restrict state)
{
	return NULL; /* TODO */
}
