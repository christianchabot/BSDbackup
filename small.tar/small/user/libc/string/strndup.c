#include <string.h>

char *
strndup(const char *s, size_t n)
{
	return NULL; /* TODO */
}
