#include <string.h>

char *
strdup(const char *s)
{
	return NULL; /* TODO */
}
